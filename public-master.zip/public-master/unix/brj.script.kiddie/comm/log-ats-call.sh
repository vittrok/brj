#!/bin/sh

nohup /usr/local/bin/scp /dev/cuaa1 /var/log/phone.log &

