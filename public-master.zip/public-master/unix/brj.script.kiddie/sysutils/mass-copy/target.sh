tar -c Ubuntu.8.10.i386.repository | nc -q0 192.168.0.1 6000
