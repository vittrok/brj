#!/usr/bin/perl
#funny script... i run it instead of telnetd... (c) 'telnet www.boston.ru'
print while (<DATA>);
__DATA__
[H[2J
[8;1H      ;,,.         
[9;1H      .;,,:,;`eeeee.
[10;1H      .,;,,.`lllllllle.
[11;1H       .;;;`:lllll;;lle'.
[12;1H      ; ",'`::llllllllle+
[13;1H      ,.';`: :llllllllllle`            
[14;1H      "'`:'" ;eee@@ellllllle.              
[15;1H      ,;';'':%@@@@@@@.llllle.             
[16;1H      ';,'.:%%@@@@@@@*llllle!             
[17;1H       ';,.@@@@@@@@@@*lllllle!             
[18;1H       ;;';';@@@@@@@@'#OOOOOOo"
[19;1H       ';';  ~@@@@@~ !OOOOOOOOo
[20;1H                     !OOOOOOOO#
[21;1H                     'OOOOOOOO'
[22;1H                      "#OOOO#'
[23;1H                         "~
[8;1H      ;,,.         
[9;1H      .;,,:,;`eeeee.
[10;1H      .,;,,.`lllllllle.
[11;1H       .;;;`:lllll;;lle'.
[12;1H      ; ",'`::llllllllle+
[13;1H      ,.';`: :llllllllllle`            
[14;1H      "'`:'" ;eee@@ellllllle.              
[15;1H      ,;';'':%@@@@@@@.llllle.             
[16;1H      ';,'.:%%@@@@@@@*llllle!             
[17;1H       ';,.@@@@@@@@@@*lllllle!             
[18;1H       ;;';';@@@@@@@@'#OOOOOOo"
[19;1H       ';';  ~@@@@@~ !OOOOOOOOo
[20;1H                     !OOOOOOOO#
[21;1H                     'OOOOOOOO'
[22;1H                      "#OOOO#'
[23;1H                         "~
[8;1H      ;,,.         
[9;1H      .;,,:,;`eeeee.
[10;1H      .,;,,.`lllllllle.
[11;1H       .;;;`:lllll;;lle'.
[12;1H      ; ",'`::lllllllllle+
[13;1H      ,.';`: :lllllllllllle`            
[14;1H      "'`:'" ;eee@@elllllllle.              
[15;1H      ,;';'':%@@@@@@@.lllllle.             
[16;1H      ';,'.:%%@@@@@@@*lllllle!             
[17;1H       ';,.@@@@@@@@@@*llllllle!             
[18;1H       ;;';';@@@@@@@@'#oOOOOOOo"
[19;1H       ';';  ~@@@@@~  !OOOOOOOOo
[20;1H                      !OOOOOOOO#
[21;1H                      `OOOOOOOO'
[22;1H                       "#OOOO#'
[23;1H                          "~
[8;1H      ;,,.         
[9;1H      .;,,:,;`eeeee.
[10;1H      .,;,,.`lllllllle.
[11;1H       .;;;`:lllll;;lle'.
[12;1H      ; ",'`::lllllllllle+
[13;1H      ,.';`: :lllllllllllle`            
[14;1H      "'`:'" ;eee@@elllllllle.              
[15;1H      ,;';'':%@@@@@@@.lllllle.             
[16;1H      ';,'.:%%@@@@@@@*lllllle!             
[17;1H       ';,.@@@@@@@@@@*llllllle!             
[18;1H       ;;';';@@@@@@@@'#oOOOOOOo"
[19;1H       ';';  ~@@@@@~  !OOOOOOOOo
[20;1H                      !OOOOOOOO#
[21;1H                      `OOOOOOOO'
[22;1H                       "#OOOO#'
[23;1H                          "~
[8;1H      ;,,.         
[9;1H      .;,,:,;`eeeee.
[10;1H      .,;,,.`lllllllle.
[11;1H       .;;;`:lllll;;lle'.
[12;1H      ; ",'`::lllllllllle+
[13;1H      ,.';`: :lllllllllllle`            
[14;1H      "'`:'" ;eee@@elllllllle.              
[15;1H      ,;';'':%@@@@@@@.llllllle.             
[16;1H      ';,'.:%%@@@@@@@*llllllle!             
[17;1H       ';,.@@@@@@@@@@*lllllllle!             
[18;1H       ;;';';@@@@@@@@@#"oOOOOOOOo`
[19;1H       ';';  ~@@@@@~   !OOOOOOOOO)
[20;1H                       `OOOOOOOOO%
[21;1H                        "OOOOOOOO' 
[22;1H                         "OOOOO#' 
[23;1H                            ~~
[8;1H      ;,,.         
[9;1H      .;,,:,;`eeeee.
[10;1H      .,;,,.`lllllllle.
[11;1H       .;;;`:lllll;;lle'.
[12;1H      ; ",'`::lllllllllle+
[13;1H      ,.';`: :lllllllllllle`            
[14;1H      "'`:'" ;eee@@elllllllle.              
[15;1H      ,;';'':%@@@@@@@.llllllle.             
[16;1H      ';,'.:%%@@@@@@@*llllllle!             
[17;1H       ';,.@@@@@@@@@@*lllllllle!             
[18;1H       ;;';';@@@@@@@@@#"oOOOOOOOo`
[19;1H       ';';  ~@@@@@~   !OOOOOOOOO)
[20;1H                       `OOOOOOOOO%
[21;1H                        "OOOOOOOO' 
[22;1H                         "OOOOO#' 
[23;1H                            ~~
[8;1H      ;,,.         
[9;1H      .;,,:,;`eeeee.
[10;1H      .,;,,.`llllllllle.
[11;1H       .;;;`:llllll;;lle'.
[12;1H      ; ",'`::lllllllllllle
[13;1H      ,.';`: :llllllllllllle\
[14;1H      "'`:'" ;eee@@ellllllllle.
[15;1H      ,;';'':%@@@@@@@.lllllllle.
[16;1H      ';,'.:%%@@@@@@@*lllllllle!
[17;1H       ';,.@@@@@@@@@@* !llllllLLL.
[18;1H       ;;';';@@@@@@@@, ".oo#OOOOOO
[19;1H       ';';  ~@@@@@~    !OOOOOOOOOO
[20;1H                        `OOOOOOOOOO
[21;1H                         "OOOOOOOO'
[22;1H                          "OOOOO#'
[23;1H                            ~~'` 
[8;1H      ;,,.         
[9;1H      .;,,:,;`eeeee.
[10;1H      .,;,,.`llllllllle.
[11;1H       .;;;`:llllll;;lle'.
[12;1H      ; ",'`::lllllllllllle
[13;1H      ,.';`: :llllllllllllle\
[14;1H      "'`:'" ;eee@@ellllllllle.
[15;1H      ,;';'':%@@@@@@@.lllllllle.
[16;1H      ';,'.:%%@@@@@@@*lllllllle!
[17;1H       ';,.@@@@@@@@@@* !llllllLLL.
[18;1H       ;;';';@@@@@@@@, ".oo#OOOOOO
[19;1H       ';';  ~@@@@@~    !OOOOOOOOOO
[20;1H                        `OOOOOOOOOO
[21;1H                         "OOOOOOOO'
[22;1H                          "OOOOO#'
[23;1H                            ~~'` 
[8;1H      ;,,.         
[9;1H      .;,,:,;`eeeee.
[10;1H      .,;,,.`llllllllle.
[11;1H       .;;;`:llllll;;lle'.
[12;1H      ; ",'`::llllllllllllle
[13;1H      ,.';`: :lllllllllllllle\
[14;1H      "'`:'" ;eee@@elllllllllle.
[15;1H      ,;';'':%@@@@@@@.elllllllle.
[16;1H      ';,'.:%%@@@@@@@* elllllllle!
[17;1H       ';,.@@@@@@@@@@*   !LLLl.***.
[18;1H       ;;';';@@@@@@@@'    e'oOOOOOOo.
[19;1H       ';';  ~@@@@@~      !OOOOOOOOOo.
[20;1H                          `OOOOOOOOOO
[21;1H                           "OOOOOOOO'
[22;1H                            "OOOOO#'
[23;1H                               ~~`  
[8;1H      ;,,.         
[9;1H      .;,,:,;`eeeee.
[10;1H      .,;,,.`llllllllle.
[11;1H       .;;;`:llllll;;lle'.
[12;1H      ; ",'`::llllllllllllle
[13;1H      ,.';`: :lllllllllllllle\
[14;1H      "'`:'" ;eee@@elllllllllle.
[15;1H      ,;';'':%@@@@@@@.elllllllle.
[16;1H      ';,'.:%%@@@@@@@* elllllllle!
[17;1H       ';,.@@@@@@@@@@*   !LLLl.***.
[18;1H       ;;';';@@@@@@@@'    e'oOOOOOOo.
[19;1H       ';';  ~@@@@@~      !OOOOOOOOOo.
[20;1H                          `OOOOOOOOOO
[21;1H                           "OOOOOOOO'
[22;1H                            "OOOOO#'
[23;1H                               ~~`  
[8;1H      ;,,.         
[9;1H      .;,,:,;`eeeee.
[10;1H      .,;,,.`llllllllle.
[11;1H       .;;;`:llllll;;lle'.
[12;1H      ; ",'`::llllllllllllle
[13;1H      ,.';`: :lllllllllllllle\
[14;1H      "'`:'" ;eee@@elllllllllle.
[15;1H      ,;';'':%@@@@@@@.`elllllllle.
[16;1H      ';,'.:%%@@@@@@@*  `ellllllle!
[17;1H       ';,.@@@@@@@@@@*   `!LLLlloo**,  
[18;1H       ;;';';@@@@@@@@'     `loOOOOOOOO.
[19;1H       ';';  ~@@@@@~        `OOOOOOOOOO.
[20;1H                             `OOOOOOOOO'
[21;1H                              `OOOOOOOO'
[22;1H                               `"*OOO*'
[23;1H                                    
[8;1H      ;,,.         
[9;1H      .;,,:,;`eeeee.
[10;1H      .,;,,.`llllllllle.
[11;1H       .;;;`:llllll;;lle'.
[12;1H      ; ",'`::llllllllllllle
[13;1H      ,.';`: :lllllllllllllle\
[14;1H      "'`:'" ;eee@@elllllllllle.
[15;1H      ,;';'':%@@@@@@@.`elllllllle.
[16;1H      ';,'.:%%@@@@@@@*  `ellllllle!
[17;1H       ';,.@@@@@@@@@@*   `!LLLlloo**,  
[18;1H       ;;';';@@@@@@@@'     `loOOOOOOOO.
[19;1H       ';';  ~@@@@@~        `OOOOOOOOOO.
[20;1H                             `OOOOOOOOO'
[21;1H                              `OOOOOOOO'
[22;1H                               `"*OOO*'
[23;1H                                    
[8;1H      ;,,.         
[9;1H      .;,,:,;`eeeee.
[10;1H      .,;,,.`lllllllllle.
[11;1H       .;;;`:llllll;;lllle.
[12;1H      ; ",'`::lllllllllllllle.
[13;1H      ,.';`: :lllllllllllllllle.
[14;1H      "'`:'" ;eee@@elllllllllllle.
[15;1H      ,;';'':%@@@@@@@. `ellllllllle.
[16;1H      ';,'.:%%@@@@@@@*   `ellllllllle.
[17;1H       ';,.@@@@@@@@@@*    `ellllhoOOOOOo
[18;1H       ;;';';@@@@@@@@'      `IToOOOOOOOOO
[19;1H       ';';  ~@@@@@~          `OOOOOOOOOO"
[20;1H                               `OOOOOOOOO"
[21;1H                                `OOOOOOOO'
[22;1H                                  `"*OO*'
[8;1H      ;,,.         
[9;1H      .;,,:,;`eeeee.
[10;1H      .,;,,.`lllllllllle.
[11;1H       .;;;`:llllll;;lllle.
[12;1H      ; ",'`::lllllllllllllle.
[13;1H      ,.';`: :lllllllllllllllle.
[14;1H      "'`:'" ;eee@@elllllllllllle.
[15;1H      ,;';'':%@@@@@@@. `ellllllllle.
[16;1H      ';,'.:%%@@@@@@@*   `ellllllllle.
[17;1H       ';,.@@@@@@@@@@*    `ellllhoOOOOOo
[18;1H       ;;';';@@@@@@@@'      `IToOOOOOOOOO
[19;1H       ';';  ~@@@@@~          `OOOOOOOOOO"
[20;1H                               `OOOOOOOOO"
[21;1H                                `OOOOOOOO'
[22;1H                                  `"*OO*'
[8;1H      ;,,.         
[9;1H      .;,,:,;`eeeee:,.
[10;1H      .,;,,.`llllllllle:\
[11;1H       .;;;`:llllll;;lllle:.
[12;1H      ; ",'`::lllllllllllllle:.
[13;1H      ,.';`: :lllllllllllllllllle.
[14;1H      "'`:'" ;eee@@elllllllllllllle.
[15;1H      ,;';'':%@@@@@@@.  `elllllllllle.
[16;1H      ';,'.:%%@@@@@@@*    `ellllllllhhe.
[17;1H       ';,.@@@@@@@@@@*      `ellllhoOOOOOo.
[18;1H       ;;';';@@@@@@@@'        `IloOOOOOOOOOo
[19;1H       ';';  ~@@@@@~            `oOOOOOOOOOO
[20;1H                                 `OOOOOOOOOO
[21;1H                                   `OOOOOOO"
[22;1H                                     `~*"''
[8;1H      ;,,.         
[9;1H      .;,,:,;`eeeee:,.
[10;1H      .,;,,.`llllllllle:\
[11;1H       .;;;`:llllll;;lllle:.
[12;1H      ; ",'`::lllllllllllllle:.
[13;1H      ,.';`: :lllllllllllllllllle.
[14;1H      "'`:'" ;eee@@elllllllllllllle.
[15;1H      ,;';'':%@@@@@@@.  `elllllllllle.
[16;1H      ';,'.:%%@@@@@@@*    `ellllllllhhe.
[17;1H       ';,.@@@@@@@@@@*      `ellllhoOOOOOo.
[18;1H       ;;';';@@@@@@@@'        `IloOOOOOOOOOo
[19;1H       ';';  ~@@@@@~            `oOOOOOOOOOO
[20;1H                                 `OOOOOOOOOO
[21;1H                                   `OOOOOOO"
[22;1H                                     `~*"''
[8;1H      ;,,.         
[9;1H      .;,,:,;`eeeeeee,.
[10;1H      .,;,,.`lllllllllle:\
[11;1H       .;;;`:llllll;;llllllle.
[12;1H      ; ",'`::lllllllllllllllle.
[13;1H      ,.';`: :llllllllllllllllllle.
[14;1H      "'`:'" ;eee@@elllllllllllllllle.
[15;1H      ,;';'':%@@@@@@@.  `"elllllllllllle.
[16;1H      ';,'.:%%@@@@@@@*      `ellllllleoOOOo.
[17;1H       ';,.@@@@@@@@@@*        `ellleOOOOOOOOo 
[18;1H       ;;';';@@@@@@@@'          `IeOOOOOOOOOO'
[19;1H       ';';  ~@@@@@~              `OOOOOOOOOO"
[20;1H                                   `*OOOOOOOO'
[21;1H                                     `~*OO*"'
[22;1H                                                     
[8;1H      ;,,.         
[9;1H      .;,,:,;`eeeeeee,.
[10;1H      .,;,,.`lllllllllle:\
[11;1H       .;;;`:llllll;;llllllle.
[12;1H      ; ",'`::lllllllllllllllle.
[13;1H      ,.';`: :llllllllllllllllllle.
[14;1H      "'`:'" ;eee@@elllllllllllllllle.
[15;1H      ,;';'':%@@@@@@@.  `"elllllllllllle.
[16;1H      ';,'.:%%@@@@@@@*      `ellllllleoOOOo.
[17;1H       ';,.@@@@@@@@@@*        `ellleOOOOOOOOo 
[18;1H       ;;';';@@@@@@@@'          `IeOOOOOOOOOO'
[19;1H       ';';  ~@@@@@~              `OOOOOOOOOO"
[20;1H                                   `*OOOOOOOO'
[21;1H                                     `~*OO*"'
[22;1H                                                     
[8;1H      ;,,.         
[9;1H      .;,,:,;`eeeeeee,.
[10;1H      .,;,,.`llllllllllle:\
[11;1H       .;;;`:llllll;;lllllllle.
[12;1H      ; ",'`::lllllllllllllllllle.
[13;1H      ,.';`: :llllllllllllllllllllle.
[14;1H      "'`:'" ;eee@@ellllllllllllllllle.
[15;1H      ,;';'':%@@@@@@@.  `""ellllllllllllee.
[16;1H      ';,'.:%%@@@@@@@*       `ellllllloOOOOOo.
[17;1H       ';,.@@@@@@@@@@*         `ellleOOOOOOOOOo 
[18;1H       ;;';';@@@@@@@@'           `eleOOOOOOOOOO' 
[19;1H       ';';  ~@@@@@~                `OOOOOOOOOO'  
[20;1H                                      `OOOOOOOO'  
[21;1H                                         `"""' 
[8;1H      ;,,.         
[9;1H      .;,,:,;`eeeeeee,.
[10;1H      .,;,,.`llllllllllle:\
[11;1H       .;;;`:llllll;;lllllllle.
[12;1H      ; ",'`::lllllllllllllllllle.
[13;1H      ,.';`: :llllllllllllllllllllle.
[14;1H      "'`:'" ;eee@@ellllllllllllllllle.
[15;1H      ,;';'':%@@@@@@@.  `""ellllllllllllee.
[16;1H      ';,'.:%%@@@@@@@*       `ellllllloOOOOOo.
[17;1H       ';,.@@@@@@@@@@*         `ellleOOOOOOOOOo 
[18;1H       ;;';';@@@@@@@@'           `eleOOOOOOOOOO' 
[19;1H       ';';  ~@@@@@~                `OOOOOOOOOO'  
[20;1H                                      `OOOOOOOO'  
[21;1H                                         `"""' 
[8;1H      ;,,.         
[9;1H      .;,,:,;`eeeeeee,.
[10;1H      .,;,,.`lllllllllllle:\
[11;1H       .;;;`:llllll;;lllllllllle.
[12;1H      ; ",'`::lllllllllllllllllllle.
[13;1H      ,.';`: :llllllllllllllllllllllle.
[14;1H      "'`:'" ;eee@@elllllllllllllllllllle..
[15;1H      ,;';'':%@@@@@@@.   `"elllllllllllllooOo.
[16;1H      ';,'.:%%@@@@@@@*        `ellllllloOOOOOOOo.
[17;1H       ';,.@@@@@@@@@@*           `elll(OOOOOOOOOO  
[18;1H       ;;';';@@@@@@@@'              `e"OOOOOOOOOOO  
[19;1H       ';';  ~@@@@@~                   `OOOOOOOOOO' 
[20;1H                                         `OOOOOOO"
[21;1H                                           ``~~'`
[8;1H      ;,,.         
[9;1H      .;,,:,;`eeeeeee,.
[10;1H      .,;,,.`lllllllllllle:\
[11;1H       .;;;`:llllll;;lllllllllle.
[12;1H      ; ",'`::lllllllllllllllllllle.
[13;1H      ,.';`: :llllllllllllllllllllllle.
[14;1H      "'`:'" ;eee@@elllllllllllllllllllle..
[15;1H      ,;';'':%@@@@@@@.   `"elllllllllllllooOo.
[16;1H      ';,'.:%%@@@@@@@*        `ellllllloOOOOOOOo.
[17;1H       ';,.@@@@@@@@@@*           `elll(OOOOOOOOOO  
[18;1H       ;;';';@@@@@@@@'              `e"OOOOOOOOOOO  
[19;1H       ';';  ~@@@@@~                   `OOOOOOOOOO' 
[20;1H                                         `OOOOOOO"
[21;1H                                           ``~~'`
[8;1H      ;,,.         
[9;1H      .;,,:,;`eeeeeeeee.
[10;1H      .,;,,.`llllllllllllle:\
[11;1H       .;;;`:llllll;;llllllllllle.
[12;1H      ; ",'`::lllllllllllllllllllllle.
[13;1H      ,.';`: :llllllllllllllllllllllllle.
[14;1H      "'`:'" ;eee@@eelllllllllllllllllllllle.
[15;1H      ,;';'':%@@@@@@@.   ``"elllllllllllooOOOOOo.
[16;1H      ';,'.:%%@@@@@@@*        ``elllllloOOOOOOOOOo.
[17;1H       ';,.@@@@@@@@@@*            `ellloOOOOOOOOOOO
[18;1H       ;;';';@@@@@@@@'               `e"OOOOOOOOOOO
[19;1H       ';';  ~@@@@@~                    `(OOOOOOOOO
[20;1H                                          `"*OOO*'
[21;1H                                                       
[8;1H      ;,,.         
[9;1H      .;,,:,;`eeeeeeeee..
[10;1H      .,;,,.`llllllllllllle:\
[11;1H       .;;;`:llllll;;llllllllllle.
[12;1H      ; ",'`::lllllllllllllllllllllle.
[13;1H      ,.';`: :llllllllllllllllllllllllle.
[14;1H      "'`:'" ;eee@@eelllllllllllllllllllllle.
[15;1H      ,;';'':%@@@@@@@.   ``"elllllllllllooOOOOOo.
[16;1H      ';,'.:%%@@@@@@@*        ``elllllloOOOOOOOOOo.
[17;1H       ';,.@@@@@@@@@@*            `ellloOOOOOOOOOOO
[18;1H       ;;';';@@@@@@@@'               `e"OOOOOOOOOOO
[19;1H       ';';  ~@@@@@~                    `(OOOOOOOOO
[20;1H                                          `"*OOO*'
[21;1H                                                       
[8;1H      ;,,.         
[9;1H      .;,,:,;`eeeeeeeeee.
[10;1H      .,;,,.`llllllllllllllle.
[11;1H       .;;;`:llllll;;lllllllllllle.
[12;1H      ; ",'`::lllllllllllllllllllllllle.
[13;1H      ,.';`: :llllllllllllllllllllllllllllee.
[14;1H      "'`:'" ;eee@@eeeeelllllllllllllllloOOOOOOo.
[15;1H      ,;';'':%@@@@@@@.      `"elllllllloOOOOOOOOOO.
[16;1H      ';,'.:%%@@@@@@@*           `ellloOOOOOOOOOOOO'
[17;1H       ';,.@@@@@@@@@@*               `elOOOOOOOOOOOO.
[18;1H       ;;';';@@@@@@@@'                  `OOOOOOOOOOO.
[19;1H       ';';  ~@@@@@~                       `"*OOOO*'
[20;1H                                                   
[8;1H      ;,,.         
[9;1H      .;,,:,;`eeeeeeeeee.
[10;1H      .,;,,.`llllllllllllllle.
[11;1H       .;;;`:llllll;;lllllllllllle.
[12;1H      ; ",'`::lllllllllllllllllllllllle.
[13;1H      ,.';`: :llllllllllllllllllllllllllllee.
[14;1H      "'`:'" ;eee@@eeeeelllllllllllllllloOOOOOOo.
[15;1H      ,;';'':%@@@@@@@.      `"elllllllloOOOOOOOOOO.
[16;1H      ';,'.:%%@@@@@@@*           `ellloOOOOOOOOOOOO'
[17;1H       ';,.@@@@@@@@@@*               `elOOOOOOOOOOOO.
[18;1H       ;;';';@@@@@@@@'                  `OOOOOOOOOOO.
[19;1H       ';';  ~@@@@@~                       `"*OOOO*'
[20;1H                                                   
[8;1H      ;,,.         
[9;1H      .;,,:,;`eeeeeeeeeee..
[10;1H      .,;,,.`llllllllllllllllee...
[11;1H       .;;;`:llllll;;llllllllllllllee...
[12;1H      ; ",'`::llllllllllllllllllllllllllle.o.
[13;1H      ,.';`: :lllllllllllllllllllllllllloOOOOOOo.
[14;1H      "'`:'" ;eee@@eeeeeelllllllllllllloOOOOOOOOOO.
[15;1H      ,;';'':%@@@@@@@.        ``"ellllloOOOOOOOOOOOo  
[16;1H      ';,'.:%%@@@@@@@*             ``ellOOOOOOOOOOOO"   
[17;1H       ';,.@@@@@@@@@@*                 ``*OOOOOOOOOO' 
[18;1H       ;;';';@@@@@@@@'                    `"*OOOOOO" 
[19;1H       ';';  ~@@@@@~                           ~~    
[8;1H      ;,,.         
[9;1H      .;,,:,;`eeeeeeeeeee..
[10;1H      .,;,,.`llllllllllllllllee...
[11;1H       .;;;`:llllll;;llllllllllllllee...
[12;1H      ; ",'`::llllllllllllllllllllllllllle.o.
[13;1H      ,.';`: :lllllllllllllllllllllllllloOOOOOOo.
[14;1H      "'`:'" ;eee@@eeeeeelllllllllllllloOOOOOOOOOO.
[15;1H      ,;';'':%@@@@@@@.        ``"ellllloOOOOOOOOOOOo  
[16;1H      ';,'.:%%@@@@@@@*             ``ellOOOOOOOOOOOO"   
[17;1H       ';,.@@@@@@@@@@*                 ``*OOOOOOOOOO' 
[18;1H       ;;';';@@@@@@@@'                    `"*OOOOOO" 
[19;1H       ';';  ~@@@@@~                           ~~    
[8;1H      ;,,.         
[9;1H      .;,,:,;`eeeeeeeeeeeee...
[10;1H      .,;,,.`llllllllllllllllllle...
[11;1H       .;;;`:llllll;;lllllllllllllllllle..
[12;1H      ; ",'`::lllllllllllllllllllllllllllll..oo..
[13;1H      ,.';`: :lllllllllllllllllllllllllllloOOOOOOOo.
[14;1H      "'`:'" ;eee@@eeeeeeellllllllllllllloOOOOOOOOOO.
[15;1H      ,;';'':%@@@@@@@.        ``"elllllll*OOOOOOOOOOO.  
[16;1H      ';,'.:%%@@@@@@@*                `"l`OOOOOOOOOOOO
[17;1H       ';,.@@@@@@@@@@*                    `OOOOOOOOOO"
[18;1H       ;;';';@@@@@@@@'                      `"~*OOO*~' 
[19;1H       ';';  ~@@@@@~                                    
[8;1H      ;,,.         
[9;1H      .;,,:,;`eeeeeeeeeeeee...
[10;1H      .,;,,.`llllllllllllllllllle...
[11;1H       .;;;`:llllll;;lllllllllllllllllle..
[12;1H      ; ",'`::lllllllllllllllllllllllllllll..oo..
[13;1H      ,.';`: :lllllllllllllllllllllllllllloOOOOOOOo.
[14;1H      "'`:'" ;eee@@eeeeeeellllllllllllllloOOOOOOOOOO.
[15;1H      ,;';'':%@@@@@@@.        ``"elllllll*OOOOOOOOOOO.
[16;1H      ';,'.:%%@@@@@@@*                `"l`OOOOOOOOOOOO
[17;1H       ';,.@@@@@@@@@@*                    `OOOOOOOOOO"
[18;1H       ;;';';@@@@@@@@'                      `"~*OOO*~' 
[19;1H       ';';  ~@@@@@~                                    
[8;1H      ;,,.         
[9;1H      .;,,:,;`eeeeeeeeeeeee....
[10;1H      .,;,,.`lllllllllllllllllllllee..
[11;1H       .;;;`:llllll;;llllllllllllllllllllll.--.
[12;1H      ; ",'`::llllllllllllllllllllllllllllOOOOOOo.
[13;1H      ,.';`: :lllllllllllllllllllllllllllOOOOOOOOOOo.
[14;1H      "'`:'" ;eee@@eeeeeeelllllllllllllllOOOOOOOOOOOOo
[15;1H      ,;';'':%@@@@@@@.          ``"~ellllOOOOOOOOOOOOO. 
[16;1H      ';,'.:%%@@@@@@@*                  `"OOOOOOOOOOOO. 
[17;1H       ';,.@@@@@@@@@@*                     `"~OOOOOOO~ 
[18;1H       ;;';';@@@@@@@@'                          `"~"   
[19;1H       ';';  ~@@@@@~                                          
[8;1H      ;,,.         
[9;1H      .;,,:,;`eeeeeeeeeeeee....
[10;1H      .,;,,.`lllllllllllllllllllllee..
[11;1H       .;;;`:llllll;;llllllllllllllllllllll.--.
[12;1H      ; ",'`::llllllllllllllllllllllllllllOOOOOOo.
[13;1H      ,.';`: :lllllllllllllllllllllllllllOOOOOOOOOOo.
[14;1H      "'`:'" ;eee@@eeeeeeelllllllllllllllOOOOOOOOOOOOo
[15;1H      ,;';'':%@@@@@@@.          ``"~ellllOOOOOOOOOOOOO. 
[16;1H      ';,'.:%%@@@@@@@*                  `"OOOOOOOOOOOO. 
[17;1H       ';,.@@@@@@@@@@*                     `"~OOOOOOO~ 
[18;1H       ;;';';@@@@@@@@'                          `"~"   
[19;1H       ';';  ~@@@@@~                                          
[8;1H      ;,,.         
[9;1H      .;,,:,;`eeeeeeeeeeeeee.........
[10;1H      .,;,,.`lllllllllllllllllllllllllleeoOOOOo.  
[11;1H       .;;;`:llllll;;llllllllllllllllllloOOOOOOOOOo. 
[12;1H      ; ",'`::lllllllllllllllllllllllllloOOOOOOOOOOOo. 
[13;1H      ,.';`: :lllllllllllllllllllllllllloOOOOOOOOOOOOo.
[14;1H      "'`:'" ;eee@@eeeeeeellllllllllllllloOOOOOOOOOOOOO   
[15;1H      ,;';'':%@@@@@@@.            ````""""`"OOOOOOOOOo.    
[16;1H      ';,'.:%%@@@@@@@*                        `"~***".     
[17;1H       ';,.@@@@@@@@@@*                                     
[18;1H       ;;';';@@@@@@@@'                                              
[19;1H       ';';  ~@@@@@~                                          
[8;1H      ;,,.         
[9;1H      .;,,:,;`eeeeeeeeeeeeee.........
[10;1H      .,;,,.`lllllllllllllllllllllllllleeoOOOOo.
[11;1H       .;;;`:llllll;;llllllllllllllllllloOOOOOOOOOo.
[12;1H      ; ",'`::lllllllllllllllllllllllllloOOOOOOOOOOOo.
[13;1H      ,.';`: :lllllllllllllllllllllllllloOOOOOOOOOOOOo.
[14;1H      "'`:'" ;eee@@eeeeeeellllllllllllllloOOOOOOOOOOOOO  
[15;1H      ,;';'':%@@@@@@@.            ````""""`"OOOOOOOOOo.   
[16;1H      ';,'.:%%@@@@@@@*                        `"~***".   
[17;1H       ';,.@@@@@@@@@@*                                     
[18;1H       ;;';';@@@@@@@@'                                              
[19;1H       ';';  ~@@@@@~                                          
[8;1H      ;,,.         
[9;1H      .;,,:,;`eeeeeee..................   oooooo..           
[10;1H      .,;,,.`llllllllllllllllllllllllllloOOOOOOOOOoo.           
[11;1H       .;;;`:llllll;;llllllllllllllllllllOOOOOOOOOOOOo.        
[12;1H      ; ",'`::lllllllllllllllllllllllllllOOOOOOOOOOOOOOo.     
[13;1H      ,.';`: :llllllllllllllllllllllllllllOOOOOOOOOOOOOo.   
[14;1H      "'`:'" ;eee@@e~~~~~~~~~~~~~~~~~~~~~~~~*OOOOOOOOO*~     
[15;1H      ,;';'':%@@@@@@@.                           ````          
[16;1H      ';,'.:%%@@@@@@@*                                 
[17;1H       ';,.@@@@@@@@@@*
[18;1H       ;;';';@@@@@@@@'  
[19;1H       ';';  ~@@@@@~ 
[8;1H      ;,,.         
[9;1H      .;,,:,;`eeeeeee..................   oooooo..
[10;1H      .,;,,.`llllllllllllllllllllllllllloOOOOOOOOOoo.
[11;1H       .;;;`:llllll;;llllllllllllllllllllOOOOOOOOOOOOo.
[12;1H      ; ",'`::lllllllllllllllllllllllllllOOOOOOOOOOOOOOo.
[13;1H      ,.';`: :llllllllllllllllllllllllllllOOOOOOOOOOOOOo.
[14;1H      "'`:'" ;eee@@e~~~~~~~~~~~~~~~~~~~~~~~~*OOOOOOOOO*~ 
[15;1H      ,;';'':%@@@@@@@.                           ````          
[16;1H      ';,'.:%%@@@@@@@* 
[17;1H       ';,.@@@@@@@@@@*
[18;1H       ;;';';@@@@@@@@'  
[19;1H       ';';  ~@@@@@~ 
[8;1H      ;,,.                                  _____
[9;1H      .;,,:,;`eeeeeeeeeeeeeeeeeeeeeeeeee *oOOOOOOOo.
[10;1H      .,;,,.`lllllllllllllllllllllllllll OOOOOOOOOOOOo
[11;1H       .;;;`:llllll;;lllllllllllllllllll OOOOOOOOOOOOOOo
[12;1H      ; ",'`::lllllllllllllllllllllllllll OOOOOOOOOOOOOO,
[13;1H      ,.';`: :llllllllllllllllllllllllllll #OOOOOOOOOOOo
[14;1H      "'`:'" ;eee@@ee"""~~~```                `~"""~`   
[15;1H      ,;';'':%@@@@@@@.                                    
[16;1H      ';,'.:%%@@@@@@@*
[17;1H       ';,.@@@@@@@@@@*
[18;1H       ;;';';@@@@@@@@' 
[19;1H       ';';  ~@@@@@~
[8;1H      ;,,.                                  _____
[9;1H      .;,,:,;`eeeeeeeeeeeeeeeeeeeeeeeeee *oOOOOOOOo.
[10;1H      .,;,,.`lllllllllllllllllllllllllll OOOOOOOOOOOOo
[11;1H       .;;;`:llllll;;lllllllllllllllllll OOOOOOOOOOOOOOo
[12;1H      ; ",'`::lllllllllllllllllllllllllll OOOOOOOOOOOOOO,
[13;1H      ,.';`: :llllllllllllllllllllllllllll #OOOOOOOOOOOo
[14;1H      "'`:'" ;eee@@ee"""~~~```                `~"""~`   
[15;1H      ,;';'':%@@@@@@@.                                    
[16;1H      ';,'.:%%@@@@@@@*
[17;1H       ';,.@@@@@@@@@@*
[18;1H       ;;';';@@@@@@@@' 
[19;1H       ';';  ~@@@@@~
[8;1H      ;,,.                            __  oooooo..
[9;1H      .;,,:,;`eeeeeeeeeeeeelllllllllllll OOOOOOOOOOo.
[10;1H      .,;,,.`lllllllllllllllllllllllllll OOOOOOOOOOOOOo
[11;1H       .;;;`:llllll;;lllllllllllllllllll OOOOOOOOOOOOOOO
[12;1H      ; ",'`::lllllllllllllllllllllllllll OOOOOOOOOOOOOo
[13;1H      ,.';`: :llllllllllllllllllllllllllll *OOOOOOOO*~'   
[14;1H      "'`:'" ;eee@@ee""~~~```                                
[15;1H      ,;';'':%@@@@@@@. 
[16;1H      ';,'.:%%@@@@@@@*   
[17;1H       ';,.@@@@@@@@@@*  
[18;1H       ;;';';@@@@@@@@'  
[19;1H       ';';  ~@@@@@~    
[8;1H      ;,,.                            __  oooooo..
[9;1H      .;,,:,;`eeeeeeeeeeeeelllllllllllll OOOOOOOOOOo.
[10;1H      .,;,,.`lllllllllllllllllllllllllll OOOOOOOOOOOOOo
[11;1H       .;;;`:llllll;;lllllllllllllllllll OOOOOOOOOOOOOOO
[12;1H      ; ",'`::lllllllllllllllllllllllllll OOOOOOOOOOOOOo
[13;1H      ,.';`: :llllllllllllllllllllllllllll *OOOOOOOO*~'
[14;1H      "'`:'" ;eee@@ee""~~~```                                
[15;1H      ,;';'':%@@@@@@@. 
[16;1H      ';,'.:%%@@@@@@@*   
[17;1H       ';,.@@@@@@@@@@*  
[18;1H       ;;';';@@@@@@@@'  
[19;1H       ';';  ~@@@@@~    
[7;1H                                            ___          
[8;1H      ;,,.                        ...eee oOOOOOoo.        
[9;1H      .;,,:,;`eeeeeeelllllllllllllllllll OOOOOOOOOOo.      
[10;1H      .,;,,.`lllllllllllllllllllllllllll OOOOOOOOOOOOO.    
[11;1H       .;;;`:llllll;;lllllllllllllllllll (OOOOOOOOOOOOOo    
[12;1H      ; ",'`::lllllllllllllllllllllllllll #OOOOOOOOOOO,`     
[13;1H      ,.';`: :llllllllllllllllllleee"""""" "***""""~` 
[14;1H      "'`:'" ;eee@@ee""~~``                                
[15;1H      ,;';'':%@@@@@@@.
[16;1H      ';,'.:%%@@@@@@@* 
[17;1H       ';,.@@@@@@@@@@*
[18;1H       ;;';';@@@@@@@@' 
[19;1H       ';';  ~@@@@@~ 
[7;1H                                            ___
[8;1H      ;,,.                        ...eee oOOOOOoo.     
[9;1H      .;,,:,;`eeeeeeelllllllllllllllllll OOOOOOOOOOo. 
[10;1H      .,;,,.`lllllllllllllllllllllllllll OOOOOOOOOOOOO. 
[11;1H       .;;;`:llllll;;lllllllllllllllllll (OOOOOOOOOOOOOo 
[12;1H      ; ",'`::lllllllllllllllllllllllllll #OOOOOOOOOOO,` 
[13;1H      ,.';`: :llllllllllllllllllleee"""""" "***""""~` 
[14;1H      "'`:'" ;eee@@ee""~~``                                
[15;1H      ,;';'':%@@@@@@@.
[16;1H      ';,'.:%%@@@@@@@* 
[17;1H       ';,.@@@@@@@@@@*
[18;1H       ;;';';@@@@@@@@' 
[19;1H       ';';  ~@@@@@~ 
[7;1H                                     _      ...
[8;1H      ;,,.                  ...eeeeeee  oOOOOOOOo.      
[9;1H      .;,,:,;`eeeeeeeeellllllllllllllll OOOOOOOOOOOo.  
[10;1H      .,;,,.`llllllllllllllllllllllllll OOOOOOOOOOOOOO.    
[11;1H       .;;;`:llllll;;lllllllllllllllllll OOOOOOOOOOOOOO    
[12;1H      ; ",'`::lllllllllllllllllllllllllll \OOOOOOOOOO"      
[13;1H      ,.';`: :lllllllllllllleeee"""""""``      ```         
[14;1H      "'`:'" ;eee@@ee~``                                     
[15;1H      ,;';'':%@@@@@@@. 
[16;1H      ';,'.:%%@@@@@@@*
[17;1H       ';,.@@@@@@@@@@* 
[18;1H       ;;';';@@@@@@@@'
[19;1H       ';';  ~@@@@@~  
[7;1H                                     _      ...
[8;1H      ;,,.                  ...eeeeeee  oOOOOOOOo.      
[9;1H      .;,,:,;`eeeeeeeeellllllllllllllll OOOOOOOOOOOo.  
[10;1H      .,;,,.`llllllllllllllllllllllllll OOOOOOOOOOOOOO.  
[11;1H       .;;;`:llllll;;lllllllllllllllllll OOOOOOOOOOOOOO   
[12;1H      ; ",'`::lllllllllllllllllllllllllll \OOOOOOOOOO"  
[13;1H      ,.';`: :lllllllllllllleeee"""""""``      ```         
[14;1H      "'`:'" ;eee@@ee~``                                     
[15;1H      ,;';'':%@@@@@@@. 
[16;1H      ';,'.:%%@@@@@@@*
[17;1H       ';,.@@@@@@@@@@* 
[18;1H       ;;';';@@@@@@@@'
[19;1H       ';';  ~@@@@@~  
[7;1H                                     _  .ooooo.. 
[8;1H      ;,,.                 ...eeeellll oOOOOOOOOOOo.       
[9;1H      .;,,:,;`eeeeelllllllllllllllllll OOOOOOOOOOOOOOo.   
[10;1H     .,;,,.`llllllllllllllllllllllllll OOOOOOOOOOOOOOO   
[11;1H       .;;;`:llllll;;lllllllllllllllllll OOOOOOOOOOOOO)    
[12;1H      ; ",'`::lllllllllllllllllllllllleel "OOOOOO*""``    
[13;1H      ,.';`: :lllllllllleeee""""`                            
[14;1H      "'`:'" ;eee@@el"  
[15;1H      ,;';'':%@@@@@@@.   
[16;1H      ';,'.:%%@@@@@@@*              
[17;1H       ';,.@@@@@@@@@@*   
[18;1H       ;;';';@@@@@@@@'   
[19;1H       ';';  ~@@@@@~   
[7;1H                                     _  .ooooo.. 
[8;1H      ;,,.                 ...eeeellll oOOOOOOOOOOo.       
[9;1H      .;,,:,;`eeeeelllllllllllllllllll OOOOOOOOOOOOOOo.   
[10;1H     .,;,,.`llllllllllllllllllllllllll OOOOOOOOOOOOOOO   
[11;1H       .;;;`:llllll;;lllllllllllllllllll OOOOOOOOOOOOO)    
[12;1H      ; ",'`::lllllllllllllllllllllllleel "OOOOOO*""``    
[13;1H      ,.';`: :lllllllllleeee""""`   
[14;1H      "'`:'" ;eee@@el"  
[15;1H      ,;';'':%@@@@@@@.   
[16;1H      ';,'.:%%@@@@@@@*              
[17;1H       ';,.@@@@@@@@@@*   
[18;1H       ;;';';@@@@@@@@'   
[19;1H       ';';  ~@@@@@~   
[6;1H                                          __  
[7;1H                                   ..e  oOOOOOoooo.  
[8;1H      ;,,.              ...eeeellllll! OOOOOOOOOOOOOo.        
[9;1H      .;,,:,;`eeeeelllllllllllllllllll OOOOOOOOOOOOOOOo    
[10;1H      .,;,,.`lllllllllllllllllllllllll;OOOOOOOOOOOOOOOo    
[11;1H       .;;;`:llllll;;llllllllllllllllllll`OOOOOOOOOOOO.     
[12;1H      ; ",'`::lllllllllllllllllllllllll**e ``""""``       
[13;1H      ,.';`: :lllllllleeee""```
[14;1H      "'`:'" ;eee@@el` 
[15;1H      ,;';'':%@@@@@@@.    
[16;1H      ';,'.:%%@@@@@@@* 
[17;1H       ';,.@@@@@@@@@@*
[18;1H       ;;';';@@@@@@@@'
[19;1H       ';';  ~@@@@@~
[6;1H                                          __  
[7;1H                                   ..e  oOOOOOoooo.  
[8;1H      ;,,.              ...eeeellllll! OOOOOOOOOOOOOo.        
[9;1H      .;,,:,;`eeeeelllllllllllllllllll OOOOOOOOOOOOOOOo    
[10;1H      .,;,,.`lllllllllllllllllllllllll;OOOOOOOOOOOOOOOo    
[11;1H       .;;;`:llllll;;llllllllllllllllllll`OOOOOOOOOOOO.     
[12;1H      ; ",'`::lllllllllllllllllllllllll**e ``""""``       
[13;1H      ,.';`: :lllllllleeee""```
[14;1H      "'`:'" ;eee@@el` 
[15;1H      ,;';'':%@@@@@@@.    
[16;1H      ';,'.:%%@@@@@@@* 
[17;1H       ';,.@@@@@@@@@@*
[18;1H       ;;';';@@@@@@@@'
[19;1H       ';';  ~@@@@@~
[6;1H                                     _   .----.    
[7;1H                               ..eel!: oOOOOOOOOOOo.   
[8;1H      ;,,.            ..eeeellllllllll OOOOOOOOOOOOOOo         
[9;1H      .;,,:,;`eeeeelllllllllllllllllll OOOOOOOOOOOOOOOO     
[10;1H      .,;,,.`llllllllllllllllllllllllll:OOOOOOOOOOOOOo"     
[11;1H       .;;;`:llllll;;llllllllllllllllllll"OOOOOO**"``      
[12;1H      ; ",'`::llllllllllllllllllee**""`                     
[13;1H      ,.';`: :llllllllee""``    
[14;1H      "'`:'" ;eee@@el`  
[15;1H      ,;';'':%@@@@@@@.       
[16;1H      ';,'.:%%@@@@@@@*      
[17;1H       ';,.@@@@@@@@@@*  
[18;1H       ;;';';@@@@@@@@' 
[19;1H       ';';  ~@@@@@~ 
[6;1H                                     _   .----.    
[7;1H                               ..eel!: oOOOOOOOOOOo.   
[8;1H      ;,,.            ..eeeellllllllll OOOOOOOOOOOOOOo         
[9;1H      .;,,:,;`eeeeelllllllllllllllllll OOOOOOOOOOOOOOOO     
[10;1H      .,;,,.`llllllllllllllllllllllllll:OOOOOOOOOOOOOo"     
[11;1H       .;;;`:llllll;;llllllllllllllllllll"OOOOOO**"``      
[12;1H      ; ",'`::llllllllllllllllllee**""`                     
[13;1H      ,.';`: :llllllllee""``
[14;1H      "'`:'" ;eee@@el`  
[15;1H      ,;';'':%@@@@@@@.       
[16;1H      ';,'.:%%@@@@@@@*      
[17;1H       ';,.@@@@@@@@@@*  
[18;1H       ;;';';@@@@@@@@' 
[19;1H       ';';  ~@@@@@~ 
[5;1H                                        ..--...    
[6;1H                                    .e oOOOOOOOOOo,.    
[7;1H                             ...eelll OOOOOOOOOOOOOOO.    
[8;1H      ;,,.            ..eellllllllllllOOOOOOOOOOOOOOOo.         
[9;1H      .;,,:,;`eeeeelllllllllllllllllll OOOOOOOOOOOOO*.`     
[10;1H      .,;,,.`llllllllllllllllllllllllll *OOOOOOOO*"       
[11;1H       .;;;`:llllll;;lllllllllllllllee""  ~~``             
[12;1H      ; ",'`::llllllllllllllle**``                         
[13;1H      ,.';`: :llllllll**``  
[14;1H      "'`:'" ;eee@@el`   
[15;1H      ,;';'':%@@@@@@@.  
[16;1H      ';,'.:%%@@@@@@@* 
[17;1H       ';,.@@@@@@@@@@*     
[18;1H       ;;';';@@@@@@@@'      
[19;1H       ';';  ~@@@@@~   
[5;1H                                        ..--...    
[6;1H                                    .e oOOOOOOOOOo,.    
[7;1H                             ...eelll OOOOOOOOOOOOOOO.    
[8;1H      ;,,.            ..eellllllllllllOOOOOOOOOOOOOOOo.         
[9;1H      .;,,:,;`eeeeelllllllllllllllllll OOOOOOOOOOOOO*.`     
[10;1H      .,;,,.`llllllllllllllllllllllllll *OOOOOOOO*"       
[11;1H       .;;;`:llllll;;lllllllllllllllee""  ~~``             
[12;1H      ; ",'`::llllllllllllllle**``                         
[13;1H      ,.';`: :llllllll**``     
[14;1H      "'`:'" ;eee@@el`   
[15;1H      ,;';'':%@@@@@@@.  
[16;1H      ';,'.:%%@@@@@@@* 
[17;1H       ';,.@@@@@@@@@@*     
[18;1H       ;;';';@@@@@@@@'      
[19;1H       ';';  ~@@@@@~   
[5;1H                                     .  ooOOOOOoo,.
[6;1H                                 ...el OOOOOOOOOOOOOo.
[7;1H                           ...eelllll OOOOOOOOOOOOOOOo 
[8;1H      ;,,.          ...elllllllllllll OOOOOOOOOOOOOOO         
[9;1H      .;,,:,;`eeeeelllllllllllllllllll OOOOOOOOOOO*'      
[10;1H      .,;,,.`lllllllllllllllllllllllllll`*OOO*""``     
[11;1H       .;;;`:llllll;;llllllllllllle*"``                   
[12;1H      ; ",'`::llllllllllllle*""`                         
[13;1H      ,.';`: :llllllle""``  
[14;1H      "'`:'" ;eee@@el`   
[15;1H      ,;';'':%@@@@@@@.  
[16;1H      ';,'.:%%@@@@@@@*   
[17;1H       ';,.@@@@@@@@@@*   
[18;1H       ;;';';@@@@@@@@' 
[19;1H       ';';  ~@@@@@~
[5;1H                                     .  ooOOOOOoo,.
[6;1H                                 ...el OOOOOOOOOOOOOo.
[7;1H                           ...eelllll OOOOOOOOOOOOOOOo 
[8;1H      ;,,.          ...elllllllllllll OOOOOOOOOOOOOOO         
[9;1H      .;,,:,;`eeeeelllllllllllllllllll OOOOOOOOOOO*'      
[10;1H      .,;,,.`lllllllllllllllllllllllllll`*OOO*""``     
[11;1H       .;;;`:llllll;;llllllllllllle*"``                   
[12;1H      ; ",'`::llllllllllllle*""`                         
[13;1H      ,.';`: :llllllle""``  
[14;1H      "'`:'" ;eee@@el`   
[15;1H      ,;';'':%@@@@@@@.  
[16;1H      ';,'.:%%@@@@@@@*   
[17;1H       ';,.@@@@@@@@@@*   
[18;1H       ;;';';@@@@@@@@' 
[19;1H       ';';  ~@@@@@~
[4;1H                                       ..*oo**... 
[5;1H                                    e oOOOOOOOOOOOoo. 
[6;1H                               ..elll OOOOOOOOOOOOOOO 
[7;1H                          ..ellllllll OOOOOOOOOOOOOO" 
[8;1H      ;,,.           .elllllllllllllll OOOOOOOOOOO*'         
[9;1H      .;,,:,;`eeeeellllllllllllllllllll "*OOO**"'`      
[10;1H      .,;,,.`llllllllllllllllllllllle*``             
[11;1H       .;;;`:llllll;;lllllllllle*"`                     
[12;1H      ; ",'`::llllllllllle*"`                           
[13;1H      ,.';`: :llllllle``  
[14;1H      "'`:'" ;eee@@el`  
[15;1H      ,;';'':%@@@@@@@. 
[16;1H      ';,'.:%%@@@@@@@*  
[17;1H       ';,.@@@@@@@@@@*  
[18;1H       ;;';';@@@@@@@@'  
[19;1H       ';';  ~@@@@@~   
[4;1H                                       ..*oo**... 
[5;1H                                    e oOOOOOOOOOOOoo. 
[6;1H                               ..elll OOOOOOOOOOOOOOO 
[7;1H                          ..ellllllll OOOOOOOOOOOOOO" 
[8;1H      ;,,.           .elllllllllllllll OOOOOOOOOOO*'         
[9;1H      .;,,:,;`eeeeellllllllllllllllllll "*OOO**"'`      
[10;1H      .,;,,.`llllllllllllllllllllllle*``             
[11;1H       .;;;`:llllll;;lllllllllle*"`                     
[12;1H      ; ",'`::llllllllllle*"`                           
[13;1H      ,.';`: :llllllle``  
[14;1H      "'`:'" ;eee@@el`  
[15;1H      ,;';'':%@@@@@@@. 
[16;1H      ';,'.:%%@@@@@@@*  
[17;1H       ';,.@@@@@@@@@@*  
[18;1H       ;;';';@@@@@@@@'  
[19;1H       ';';  ~@@@@@~   
[4;1H                                       .oOOOOooo..
[5;1H                                  ..e oOOOOOOOOOOOOo.
[6;1H                             ..elllll OOOOOOOOOOOOOO. 
[7;1H                        ..ellllllllll OOOOOOOOOOOOOO" 
[8;1H      ;,,.          .ellllllllllllllll OOOOOOOOO**"         
[9;1H      .;,,:,;`eeeeellllllllllllllllllle "**""'``         
[10;1H      .,;,,.`lllllllllllllllllllllle''                 
[11;1H       .;;;`:llllll;;llllllllle''                        
[12;1H      ; ",'`::lllllllllllle''              
[13;1H      ,.';`: :llllllle''          
[14;1H      "'`:'" ;eee@@el`       
[15;1H      ,;';'':%@@@@@@@.     
[16;1H      ';,'.:%%@@@@@@@*    
[17;1H       ';,.@@@@@@@@@@*  
[18;1H       ;;';';@@@@@@@@' 
[19;1H       ';';  ~@@@@@~  
[4;1H                                       .oOOOOooo..
[5;1H                                  ..e oOOOOOOOOOOOOo.
[6;1H                             ..elllll OOOOOOOOOOOOOO. 
[7;1H                        ..ellllllllll OOOOOOOOOOOOOO" 
[8;1H      ;,,.          .ellllllllllllllll OOOOOOOOO**"         
[9;1H      .;,,:,;`eeeeellllllllllllllllllle "**""'``        
[10;1H      .,;,,.`lllllllllllllllllllllle''                
[11;1H       .;;;`:llllll;;llllllllle''       
[12;1H      ; ",'`::lllllllllllle''      
[13;1H      ,.';`: :llllllle''       
[14;1H      "'`:'" ;eee@@el`       
[15;1H      ,;';'':%@@@@@@@.     
[16;1H      ';,'.:%%@@@@@@@*    
[17;1H       ';,.@@@@@@@@@@*  
[18;1H       ;;';';@@@@@@@@' 
[19;1H       ';';  ~@@@@@~  
[4;1H                                       .oOOOOooo..
[5;1H                                  ..e oOOOOOOOOOOOOo.
[6;1H                             ..elllll OOOOOOOOOOOOOO. 
[7;1H                        ..ellllllllll OOOOOOOOOOOOOO" 
[8;1H      ;,,.          .ellllllllllllllll OOOOOOOOO**"         
[9;1H      .;,,:,;`eeeeellllllllllllllllllle "**""'``         
[10;1H      .,;,,.`lllllllllllllllllllllle''                 
[11;1H       .;;;`:llllll;;llllllllle''                        
[12;1H      ; ",'`::lllllllllllle''              
[13;1H      ,.';`: :llllllle''          
[14;1H      "'`:'" ;eee@@el`       
[15;1H      ,;';'':%@@@@@@@.     
[16;1H      ';,'.:%%@@@@@@@*    
[17;1H       ';,.@@@@@@@@@@*  
[18;1H       ;;';';@@@@@@@@' 
[19;1H       ';';  ~@@@@@~  
[4;1H                                       .oOOOOooo..
[5;1H                                  ..e oOOOOOOOOOOOOo.
[6;1H                             ..elllll OOOOOOOOOOOOOO. 
[7;1H                        ..ellllllllll OOOOOOOOOOOOOO" 
[8;1H      ;,,.          .ellllllllllllllll OOOOOOOOO**"         
[9;1H      .;,,:,;`eeeeellllllllllllllllllle "**""'``        
[10;1H      .,;,,.`lllllllllllllllllllllle''                
[11;1H       .;;;`:llllll;;llllllllle''       
[12;1H      ; ",'`::lllllllllllle''      
[13;1H      ,.';`: :llllllle''       
[14;1H      "'`:'" ;eee@@el`       
[15;1H      ,;';'':%@@@@@@@.     
[16;1H      ';,'.:%%@@@@@@@*    
[17;1H       ';,.@@@@@@@@@@*  
[18;1H       ;;';';@@@@@@@@' 
[19;1H       ';';  ~@@@@@~  
[1;1H                                                                     
       
[2;1H                                       ..----..                      
[3;1H                                    .oOOOOOOOOOOOo,                  
[4;1H                                 .  OOOOOOOOOOOOO%~*                 
[5;1H                             .ellll OOOOOOOOOOOOOOO~                 
[6;1H                          .ellllllll OOOOOOOOOOOO*~                  
[7;1H                      .ellllll;;;;lll "OOOOOOO*~                     
[8;1H      ;,,.        .e;;;;;;;;;;;lllllllle ~~`                         
[9;1H      .;,,:,;`eeeellllllll;;llllllle'`                            
[10;1H      .,;,,.`llllllllllll;;lllle'`             
[11;1H       .;;;`:lllllllllll;;le'`              
[12;1H      ; ",'`::llllllllle'`             
[13;1H      ,.';`: :llllllle''       
[14;1H      "'`:'" ;eee@@el`       
[15;1H      ,;';'':%@@@@@@@.     
[16;1H      ';,'.:%%@@@@@@@*    
[17;1H       ';,.@@@@@@@@@@*  
[18;1H       ;;';';@@@@@@@@' 
[19;1H       ';';  ~@@@@@~  

[1;1H                                                         .*.#*"..    
[2;1H                                       ..----..       ..##@@*@ '     
[3;1H                                    .oOOOOOOOOOOOo, .#@@#* '         
[4;1H                                 .  OOOOOOOOOOOOO%~*@*`              
[5;1H                             .ellll OOOOOOOOOOOOOOO~                 
[1;1H                                                          
[2;1H                                       ..----..        .#@@@@#'" .  '
[3;1H                                    .oOOOOOOOOOOOo, .@@@#*"' `       
[4;1H                                 .  OOOOOOOOOOOOO%~*                 
[5;1H                             .ellll OOOOOOOOOOOOOOO~             
[1;1H                                                            
[2;1H                                       ..----..           .#@@@@@@#'"
[3;1H                                    .oOOOOOOOOOOOo,  .*.#*"' `  "    
[4;1H                                 .  OOOOOOOOOOOOO%~*             
[5;1H                             .ellll OOOOOOOOOOOOOOO~             
[1;1H                                                            
[2;1H                                       ..----..           . '* **
[3;1H                                    .oOOOOOOOOOOOo,   .. *"' `  "    
[4;1H                                 .  OOOOOOOOOOOOO%~* 
[5;1H                             .ellll OOOOOOOOOOOOOOO~
[1;1H                                                            
[3;1H                                    .oOOOOOOOOOOOo,   ..` "  `       
[4;1H                                 .  OOOOOOOOOOOOO%~* 
[5;1H                             .ellll OOOOOOOOOOOOOOO~
[1;1H                                                              .  
[2;1H                                       ..----..            .    .
[3;1H                                    .oOOOOOOOOOOOo,    .` '          
[4;1H                                 .  OOOOOOOOOOOOO%~*                 
[5;1H                             .ellll OOOOOOOOOOOOOOO~
[1;1H                                                                . .  
[2;1H                                       ..----..             .   .    
[3;1H                                    .oOOOOOOOOOOOo,      .           
[4;1H                                 .  OOOOOOOOOOOOO%~*                 
[5;1H                             .ellll OOOOOOOOOOOOOOO~
[1;1H                                                                     
[2;1H                                       ..----..                    '.
[3;1H                                    .oOOOOOOOOOOOo,                  
[4;1H                                 .  OOOOOOOOOOOOO%~*                 
[5;1H                             .ellll OOOOOOOOOOOOOOO~
[1;1H                                                                     
[2;1H                                                                     
[3;1H                                                                     
[4;1H                                       .oOOOOooo..                   
[5;1H                                  ..e oOOOOOOOOOOOOo.                
[6;1H                             ..elllll OOOOOOOOOOOOOO.                
[7;1H                        ..ellllllllll OOOOOOOOOOOOOO"                
[8;1H      ;,,.          .ellllllllllllllll OOOOOOOOO**"                  
[9;1H      .;,,:,;`eeeeellllllllllllllllllle "**""'``                     
[10;1H      .,;,,.`lllllllllllllllllllllle''                              
[11;1H       .;;;`:llllll;;llllllllle''                     
[12;1H      ; ",'`::lllllllllllle''      
[13;1H      ,.';`: :llllllle''       
[4;1H                                       ..*oo**...           
[5;1H                                    e oOOOOOOOOOOOoo.         
[6;1H                               ..elll OOOOOOOOOOOOOOO            
[7;1H                          ..ellllllll OOOOOOOOOOOOOO"        
[8;1H      ;,,.           .elllllllllllllll OOOOOOOOOOO*'            
[9;1H      .;,,:,;`eeeeellllllllllllllllllll "*OOO**"'`             
[10;1H      .,;,,.`llllllllllllllllllllllle*``                     
[11;1H       .;;;`:llllll;;lllllllllle*"`                            
[12;1H      ; ",'`::llllllllllle*"`                                 
[13;1H      ,.';`: :llllllle``                  
[4;1H                                                          
[5;1H                                     .  ooOOOOOoo,. 
[6;1H                                 ...el OOOOOOOOOOOOOo. 
[7;1H                           ...eelllll OOOOOOOOOOOOOOOo 
[8;1H      ;,,.          ...elllllllllllll OOOOOOOOOOOOOOO         
[9;1H      .;,,:,;`eeeeelllllllllllllllllll OOOOOOOOOOO*'      
[10;1H      .,;,,.`lllllllllllllllllllllllllll`*OOO*""``     
[11;1H       .;;;`:llllll;;llllllllllllle*"``                   
[12;1H      ; ",'`::llllllllllllle*""`                         
[13;1H      ,.';`: :llllllle""``  
[4;1H                                       ..*oo**... 
[5;1H                                    e oOOOOOOOOOOOoo. 
[6;1H                               ..elll OOOOOOOOOOOOOOO 
[7;1H                          ..ellllllll OOOOOOOOOOOOOO" 
[8;1H      ;,,.           .elllllllllllllll OOOOOOOOOOO*'         
[9;1H      .;,,:,;`eeeeellllllllllllllllllll "*OOO**"'`      
[10;1H      .,;,,.`llllllllllllllllllllllle*``             
[11;1H       .;;;`:llllll;;lllllllllle*"`                     
[12;1H      ; ",'`::llllllllllle*"`                           
[13;1H      ,.';`: :llllllle``  
[4;1H                                       .oOOOOooo..   
[5;1H                                  ..e oOOOOOOOOOOOOo.   
[23;1H                                                    
