#!/bin/sh

for i in $(cat nodes | awk {'print $1'}); do j=$(cat nodes | grep $i | awk {'print $2'}); ssh DHCP
for i in $(cat nodeswip | awk {'print $8'}); do j=$(grep $i nodeswip|awk {'print $14'}); expect e

