# whois -h whois.krs-ix.ru '172.19.40.50 -e koi8-r'
