<?php
/**
 * English language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Brj <sam@brj.pp.ru>
 */
 
// for the configuration manager
$lang['idnamespace']      = 'Куда перекидывать пользователя, пришедшего на "404 несуществующая страница"';
