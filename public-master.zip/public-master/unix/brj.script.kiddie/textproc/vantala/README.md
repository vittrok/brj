Слова ванталы + PushBullet for PHP
==================================

Это даже не совсем гадание, скорее это пища для размышлений. 
Здесь собраны афоризмы из учения старой китайской философской школы "Дао Цзи Бай". 
Гадающий получает наиболее актуальный для себя афоризм, то над чем имеет смысл поразмышлять сегодня, а возможно это будет ответ на давно мучающий вопрос.

## Description
For more information, you can refer to these links:
* https://github.com/ivkos/PushBullet-for-PHP
* PushBullet for Android: https://play.google.com/store/apps/details?id=com.pushbullet.android
* API reference: https://www.pushbullet.com/api
* Blog: http://blog.pushbullet.com

## Requirements
* PHP 5
* cURL library for PHP
* Your PushBullet API key (get it here: https://www.pushbullet.com/account)
