<?php
/**
 * Metadata for configuration manager plugin
 * Additions for the brj404 plugin
 *
 * @author    Brj <sam@brj.pp.ru>
 */

$meta['idnamespace']      = array('string');
