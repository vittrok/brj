<?
include "./news/index.php";
?>