<?php
include "./news/index.ru.php";
?>