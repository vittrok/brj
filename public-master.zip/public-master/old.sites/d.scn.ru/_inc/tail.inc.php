<!-- //BODY -->
		</td>
	<td valign=top width="120px">
<? include "google.txt" ?>
	</td>

	</tr>
	<tr>
		<td colspan=2 align=left valign=top>
<!-- TAIL -->
<br>
--<br>
/dikiy<br>
(c) 2000-2004 Andrew I Baznikin<br>


<!-- COUNTERS -->
<? show_counter() ?>

<!-- SpyLOG v2 f:0211 --> 
<script language="javascript"> 
u="u120.65.spylog.com";d=document;nv=navigator;na=nv.appName;t="";p=0; 
sz=" width=88 height=31 "; 
hl=history.length;d.cookie="b=b";c=0; 
bv=Math.round(parseFloat(nv.appVersion)*100); 
if (d.cookie) c=1;n=(na.substring(0,2)=="Mi")?0:1; 
if((n==0)||(bv >= 300)){rn=Math.random();t=(new Date()).getTimezoneOffset();} else {rn=0;} 
z="p="+p+"&rn="+rn+"&t="+t+"&c="+c+"&hl="+hl; 
if (self != top) { fr=1;} else { fr=0;} 
r=escape(d.referrer);r1=""; 
sl="1.0";h=0; 
</script> 
<script language="javascript1.1"> 
pl="";sl="1.1"; 
if((n==1) && (bv >= 300)) 
{ for(var i = 0; i < nv.plugins.length; i++) 
pl += nv.plugins[i].name+":"; } 
j = (navigator.javaEnabled() ? "Y" : "N"); 
</script> 
<script language=javascript1.2> 
sl="1.2";s=screen;wh=s.width+'x'+s.height; 
px=(n==0)?screen.colorDepth:screen.pixelDepth;z+="&wh="+wh+"&px="+px; 
</script> 
<script language=javascript1.3> 
sl="1.3" 
</script> 
<script language="javascript"> 
y=""; 
y+="<a href='http://"+u+"/cnt?f=3&p="+p+"&rn="+rn+"' target=_blank>"; 
y+="<img src='http://"+u+"/cnt?"; 
y+=z+"&j="+j+"&sl="+sl+"&r="+r+"&r1="+r1+"&fr="+fr+"&pg="+escape(window.location.href)+"&pl="+escape(pl); 
y+="' border=0 "+sz+" alt='SpyLOG'>"; 
y+="</a>"; 
d.write(y); 
</script> 
<script language="javascript1.2"><!-- 
if (n == 0) { d.write("<");d.write("!--"); } 
//--></script> 
<noscript> 
<a href="http://u120.65.spylog.com/cnt?f=3&p=0" target=_blank> 
<img src="http://u120.65.spylog.com/cnt?p=0" alt='SpyLOG' border='0' width=88 height=31 > 
</a> 
</noscript> 
<script language="javascript1.2"><!-- 
if (n == 0) { d.write("--");d.write(">"); } 
//--></script> 
<!-- SpyLOG -->

<a href="http://www.stalker.internet.ru/krsk/" target="_new"><img src="http://www.stalker.internet.ru/counter.asp?id=657:1" width="88" height="31" border="0" alt="Stalker TOP"></a>

<!-- //COUNTERS -->

<!-- //TAIL-->
		</td>
	</tr>
</table>

</body>
</html>
