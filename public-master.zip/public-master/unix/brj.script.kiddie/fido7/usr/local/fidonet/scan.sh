#!/bin/sh
cd /usr/local/fidonet/hpt
./hpt -c /usr/local/fidonet/hpt/config scan pack
