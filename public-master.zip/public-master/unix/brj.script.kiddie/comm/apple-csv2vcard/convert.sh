#!/bin/sh

gawk -f csv2apple-icloud.awk import.csv
