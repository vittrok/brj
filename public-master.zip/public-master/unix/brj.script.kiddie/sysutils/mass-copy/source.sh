nc -q0 -l -p 6000 | tar -x
