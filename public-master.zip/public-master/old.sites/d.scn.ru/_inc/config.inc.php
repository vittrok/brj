<?php

$site_path="/usr/local/www/clients/d/data";

$site_root="";
$site_real_root="$site_path$site_root";

$log_404_name = "$site_path$site_root/_log/404.log";
$log_referer_name = "$site_path$site_root/_log/referer.log";

?>