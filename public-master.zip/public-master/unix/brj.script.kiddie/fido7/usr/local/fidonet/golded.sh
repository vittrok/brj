#!/bin/sh
cd /usr/local/fidonet/golded
./golded
/usr/local/fidonet/scan.sh
