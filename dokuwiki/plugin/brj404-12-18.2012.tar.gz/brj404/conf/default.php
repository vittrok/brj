<?php
/**
 * Options for the brj404 Plugin
 */
$conf['idnamespace']      = 'start';       // where should links point to? default: 'start'
