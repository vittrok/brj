sshot ()
{ sleep 5; import -window root `date "+%Y-%m-%d%--%H:%M:%S"`.jpg }
