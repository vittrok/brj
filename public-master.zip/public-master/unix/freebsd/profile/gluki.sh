#!/bin/csh

# Sample .login file

stty erase ^H intr ^C susp ^Z

echo "Welcome to Wiliki\!"

frm -s n
