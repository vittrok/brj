<?php
include "./news/index.en.php";
?>