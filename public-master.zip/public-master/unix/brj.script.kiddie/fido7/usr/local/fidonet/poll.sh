#!/bin/sh
/usr/local/fidonet/binkd/binkd /usr/local/fidonet/binkd/binkd.cfg -P 2:5090/1029
