#!/usr/bin/perl

@ip=split(/:/,$ARGV[6]);
print $ip[0];
