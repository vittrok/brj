<?php
/**
 * English language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Brj <sam@brj.pp.ru>
 */
 
// for the configuration manager
$lang['idnamespace']      = 'Default redirect namespace for "404 Not found page"';
