ЗАО "The бырдж"
===============

## what?
Roman Y. Bogdanov public script repo

## wiki
migrate from dokuwiki to github

## plan
1. do not try this at home
2. that's all

## contact
Roman Y. Bogdanov, http://brj.pp.ru/
