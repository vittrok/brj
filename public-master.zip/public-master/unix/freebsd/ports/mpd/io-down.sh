#!/bin/sh

#
# brj@mpd IP-linkdown script
#

case "$1" in

    *)
    
	    # nothing

	    ;;
	    
esac

