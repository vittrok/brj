#!/bin/sh

cat install-script.sh > brj@russifity.sh

uuencode rc.conf.addon rc.conf.addon >> brj@russifity.sh 
uuencode cp866-8x16.fnt cp866-8x16.fnt >> brj@russifity.sh
uuencode ru.koi8-r.kbd ru.koi8-r.kbd >> brj@russifity.sh




